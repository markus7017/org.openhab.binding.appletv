"""AirPlay related functionality."""
