"""Actual implementation of the communication protocol goes here."""
